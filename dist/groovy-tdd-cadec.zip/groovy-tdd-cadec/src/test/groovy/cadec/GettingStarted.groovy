package cadec

import org.junit.Test

class GettingStarted {

	@Test
	void testMethodInGroovy() {
		assert false, "my first failing Groovy test"
	}

}
