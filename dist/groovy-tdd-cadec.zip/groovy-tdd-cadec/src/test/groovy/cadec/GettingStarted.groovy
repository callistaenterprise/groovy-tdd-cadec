package cadec

import org.junit.Test
import static org.junit.Assert.assertTrue

class GettingStarted {

	@Test
	void testMethodInGroovy() {
		assertTrue("my first failing Groovy test", false)
	}

}
