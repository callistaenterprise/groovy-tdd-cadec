package org.springframework.samples.petclinic.web.pages

import geb.Page

class ErrorPage extends PetClinicPage {

}
