package cadec

class DivisionFixture {

	double numerator
	double denominator
	double quotient() {
		numerator / denominator
	}
}
